package Mail;

public interface IJavaMail {
}

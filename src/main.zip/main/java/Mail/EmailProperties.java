package Mail;

public class EmailProperties {


    public class MailConfig {

        public static final String HOST_NAME = "smtp.gmail.com";

        public static final int SSL_PORT = 465; // Port for SSL

        public static final int TSL_PORT = 587; // Port for TLS/STARTTLS

        public static final String APP_EMAIL = "khoangoquan@gmail.com"; // your email

        public static final String APP_PASSWORD = "mzrs xvca qstr zegw"; // your password

    }

}


package Controller;

import Dao.CartItemDAO;
import Dao.CartDAO;
import Entity.CartItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AddToCartServlet.class.getName());

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("User not logged in.");
            return;
        }

        try {
            int propertyId = Integer.parseInt(request.getParameter("propertyId"));
            String title = request.getParameter("title");
            double price = Double.parseDouble(request.getParameter("price"));
            double area = Double.parseDouble(request.getParameter("area"));
            String imageUrl = request.getParameter("imageUrl");
            String address = request.getParameter("address");

            // Ensure a valid cart_id exists for this user
            CartDAO cartDAO = new CartDAO();
            int cartId = cartDAO.createCartIfNotExists(userId);

            // Create the CartItem
            CartItem cartItem = new CartItem();
            cartItem.setCartId(cartId);
            cartItem.setUserId(userId);
            cartItem.setPropertyId(propertyId);
            cartItem.setTitle(title);
            cartItem.setPrice(price);
            cartItem.setArea(area);
            cartItem.setImageUrl(imageUrl);
            cartItem.setQuantity(1);

            // Add item to cartitems table
            CartItemDAO cartItemDAO = new CartItemDAO();
            cartItemDAO.addCartItem(cartId, cartItem);

            out.print("Item added to cart successfully.");

        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("Failed to add item to cart.");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("Invalid input.");
        }
    }
}

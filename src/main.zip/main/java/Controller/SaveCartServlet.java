package Controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/saveCart")
public class SaveCartServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        StringBuilder sb = new StringBuilder();
        String line;
        try (BufferedReader reader = request.getReader()) {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }

        System.out.println("Received JSON data: " + sb.toString());

        JSONObject jsonResponse = new JSONObject();
        Connection conn = null;
        PreparedStatement insertCartStmt = null;
        PreparedStatement insertItemStmt = null;
        ResultSet generatedKeys = null;

        try {
            JSONObject jsonRequest = new JSONObject(sb.toString());
            int userId = jsonRequest.getInt("userId");
            Integer cartId = jsonRequest.has("cartId") ? jsonRequest.getInt("cartId") : null;
            JSONArray cartItems = jsonRequest.getJSONArray("cartItems");

            String url = "jdbc:mysql://localhost:3306/webbds?useUnicode=true&characterEncoding=UTF-8&useSSL=false";
            String dbUser = "root";
            String dbPassword = "123456";

            conn = DriverManager.getConnection(url, dbUser, dbPassword);
            conn.setAutoCommit(false);

            // If cartId is null, create a new cart
            if (cartId == null) {
                String insertCartQuery = "INSERT INTO cart (user_id) VALUES (?)";
                insertCartStmt = conn.prepareStatement(insertCartQuery, Statement.RETURN_GENERATED_KEYS);
                insertCartStmt.setInt(1, userId);
                int affectedRows = insertCartStmt.executeUpdate();

                if (affectedRows == 0) {
                    throw new SQLException("Failed to create cart; no rows affected.");
                }

                generatedKeys = insertCartStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    cartId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Failed to create cart; cartId not obtained.");
                }
            }

            // Insert each cart item with quantity set to 1
            String insertItemQuery = "INSERT INTO cartitems (cart_id, user_id, property_id, title, price, area, image_url, quantity) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 1) " + // Quantity is always 1
                    "ON DUPLICATE KEY UPDATE quantity = 1"; // Ensures quantity stays 1 if item already exists
            insertItemStmt = conn.prepareStatement(insertItemQuery);

            for (int i = 0; i < cartItems.length(); i++) {
                JSONObject item = cartItems.getJSONObject(i);
                int propertyId = item.getInt("id");

                insertItemStmt.setInt(1, cartId); // cart_id
                insertItemStmt.setInt(2, userId); // user_id
                insertItemStmt.setInt(3, propertyId); // property_id
                insertItemStmt.setString(4, item.getString("title")); // title
                insertItemStmt.setDouble(5, item.getDouble("price")); // price
                insertItemStmt.setDouble(6, item.getDouble("area"));  // area
                insertItemStmt.setString(7, item.getString("imageUrl")); // image_url

                insertItemStmt.addBatch();
            }

            insertItemStmt.executeBatch();
            conn.commit();

            jsonResponse.put("success", true);
            jsonResponse.put("message", "Cart saved successfully.");
            jsonResponse.put("cartId", cartId);

        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            e.printStackTrace();
            jsonResponse.put("success", false);
            jsonResponse.put("message", "Error saving cart: " + e.getMessage());

        } finally {
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (insertCartStmt != null) insertCartStmt.close();
                if (insertItemStmt != null) insertItemStmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            out.print(jsonResponse.toString());
            out.flush();
        }
    }
}

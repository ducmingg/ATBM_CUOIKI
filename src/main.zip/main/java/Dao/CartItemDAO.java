package Dao;

import DBcontext.Database;
import Entity.CartItem;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartItemDAO {

    // Add a new item to the CartItems table
//    public void addCartItem(int cartId, CartItem item) throws SQLException {
//        String query = "INSERT INTO CartItems (cart_id, user_id, property_id, title, price, area, image_url, quantity) VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
//        try (Connection con = Database.getConnection();
//             PreparedStatement stmt = con.prepareStatement(query)) {
//            stmt.setInt(1, cartId);
//            stmt.setInt(2, item.getUserId()); // Ensure user_id is correct and matches cart
//            stmt.setInt(3, item.getPropertyId());
//            stmt.setString(4, item.getTitle());
//            stmt.setDouble(5, item.getPrice());
//            stmt.setDouble(6, item.getArea());
//            stmt.setString(7, item.getImageUrl());
//            stmt.executeUpdate();
//        }
//    }

    // Ensure a cart exists for a given user and return cart_id
    public int createCartIfNotExists(int userId) throws SQLException {
        int cartId = getCartIdByUserId(userId);

        if (cartId == -1) {
            String insertCartQuery = "INSERT INTO Cart (user_id) VALUES (?)";
            try (Connection con = Database.getConnection();
                 PreparedStatement stmt = con.prepareStatement(insertCartQuery, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, userId);
                stmt.executeUpdate();

                // Retrieve the generated cart_id
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    cartId = generatedKeys.getInt(1);
                }
            }
        }
        return cartId;
    }

    public int getCartIdByUserId(int userId) throws SQLException {
        String query = "SELECT cart_id FROM Cart WHERE user_id = ?";
        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("cart_id");
            }
        }
        return -1; // Return -1 if cart not found
    }

    // Retrieve all cart items for a specific cart
    public List<CartItem> getCartItemsByCartId(int cartId) throws SQLException {
        String query = "SELECT * FROM CartItems WHERE cart_id = ?";
        List<CartItem> cartItems = new ArrayList<>();

        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cartId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                CartItem item = new CartItem();
                item.setCartItemId(rs.getInt("id"));
                item.setCartId(cartId);
                item.setPropertyId(rs.getInt("property_id"));
                item.setTitle(rs.getString("title"));
                item.setPrice(rs.getDouble("price"));
                item.setArea(rs.getDouble("area"));
                item.setImageUrl(rs.getString("image_url"));
                item.setQuantity(1); // Quantity is always 1 for real estate items
                cartItems.add(item);
            }
        }
        return cartItems;
    }

    // Remove a cart item by cart_id and property_id
    public void removeCartItem(int cartId, int propertyId) throws SQLException {
        String query = "DELETE FROM CartItems WHERE cart_id = ? AND property_id = ?";
        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cartId);
            stmt.setInt(2, propertyId);
            stmt.executeUpdate();
        }
    }

    // Clear all items for a specific cart (e.g., upon checkout)
    public void clearCartForUser(int cartId) throws SQLException {
        String query = "DELETE FROM CartItems WHERE cart_id = ?";
        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cartId);
            stmt.executeUpdate();
        }
    }

    public boolean checkIfItemExists(int cartId, int propertyId) throws SQLException {
        String query = "SELECT COUNT(*) FROM cartitems WHERE cart_id = ? AND property_id = ?";
        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cartId);
            stmt.setInt(2, propertyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    public void addCartItem(int cartId, CartItem item) throws SQLException {
        String query = "INSERT INTO cartitems (cart_id, user_id, property_id, title, price, area, image_url, quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Database.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cartId);                      // cart_id
            stmt.setInt(2, item.getUserId());            // user_id
            stmt.setInt(3, item.getPropertyId());        // property_id
            stmt.setString(4, item.getTitle());          // title
            stmt.setBigDecimal(5, BigDecimal.valueOf(item.getPrice())); // price
            stmt.setBigDecimal(6, BigDecimal.valueOf(item.getArea()));  // area
            stmt.setString(7, item.getImageUrl());       // image_url
            stmt.setInt(8, item.getQuantity());          // quantity
            stmt.executeUpdate();
        }
    }



}
